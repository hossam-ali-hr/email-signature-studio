# Hossam Email Signature Studio

Static, client-side signature editor for GitHub Pages.

## Publish via GitHub Pages

1. Create a new **public** GitHub repository (for example `email-signature-studio`).
2. Upload `index.html` to the repository root and commit.
3. Go to **Settings → Pages → Build and deployment**.
4. Choose **Deploy from a branch**, branch **main**, folder **/(root)**, then **Save**.
5. Open `https://YOUR_USERNAME.github.io/email-signature-studio/` when GitHub finishes deployment.

## Storage limitations

Saved signatures and images are stored **in the browser's IndexedDB**, scoped to the site's origin. GitHub Pages hosts the website, but **does not store or sync user signatures**. Saved content can be lost when clearing site data or changing devices/browsers. Export backups regularly from **My Signatures → Download Backup**. Use **Import Backup** to restore.

For automatic cross-device sync, add authentication and a separate storage backend (for example, Supabase database + private object storage with access policies). Do not commit personal images or signature data to a public GitHub repository.

## Outlook images

A Data URL embedded in copied signature HTML may not render for recipients in Outlook. Prefer a stable publicly reachable HTTPS direct image URL when possible.
